//typedef float data_type;
 #include "ap_fixed.h"
typedef ap_fixed<16,8> data_type;
typedef ap_fixed<32,16> long_data_type;
typedef ap_fixed<48,24> long_long_data_type;
data_type PID (data_type set_point, data_type KP, data_type KI, data_type KD, data_type sample, data_type ts, data_type pmax);
